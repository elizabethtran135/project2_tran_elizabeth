//BACKSTRETCH SETTINGS

$.backstretch("images/yellowbkgrd.jpg");
